# Investigation Summary

## Scenario

Security Onion generated a Suricata alert involving `192.168.194.129` on 21 July 2026. The investigation reviewed Security Onion alerts, Suricata alerts, Zeek logs, and available Wireshark/PCAP evidence.

## Observed Activity

The first documented event was an ET SCAN alert involving TCP port `1433` (MSSQL) from `192.168.194.129` toward `192.168.194.1`. Additional alerts involved database service ports `1521`, `3306`, and `5432`.

Security Onion reported 42 alerts across 7 alert groups over 30 days. A `.cfd` DNS activity indicator was also reported, although the exact domain and complete DNS/PCAP details were not available.

## Analysis

The repeated targeting of multiple database ports is consistent with possible port scanning or probing. The available evidence does not establish whether successful database access occurred.

## Classification

**Suspicious — Medium severity — Medium confidence.**

The incident remains open pending additional endpoint, Zeek, DNS, and PCAP evidence.

## Lessons Learned

- Correlate Suricata alerts with Zeek connection/DNS logs and Wireshark PCAP evidence.
- Maintain complete network and endpoint evidence.
- Monitor repeated multi-port scanning patterns.
- Document timelines, IOCs, severity, and confidence consistently.
