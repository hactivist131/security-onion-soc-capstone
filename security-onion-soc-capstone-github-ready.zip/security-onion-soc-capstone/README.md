# Security Onion SOC Alert Analysis and Incident Investigation

**Capstone Project — Cyber Security**  
**Student:** Idan E. Ekitela

## Project Overview

This capstone project demonstrates a practical Security Operations Center (SOC) investigation using Security Onion. The investigation focuses on detecting, triaging, and analyzing suspicious network activity using Security Onion, Suricata, Zeek, and Wireshark.

The documented investigation identified repeated targeting of internal database service ports from `192.168.194.129` toward `192.168.194.1`. The observed ports included MSSQL `1433`, Oracle `1521`, MySQL `3306`, and PostgreSQL `5432`. A `.cfd` DNS query was also reported. Based on the available evidence, the activity was classified as **suspicious**, with **Medium severity** and **Medium confidence**. No successful compromise was confirmed.

## Investigation Objectives

- Review and triage SOC alerts.
- Analyze Suricata IDS alerts.
- Use Zeek logs as an investigation pivot.
- Review available Wireshark/PCAP evidence.
- Identify indicators of compromise (IOCs).
- Build a network activity timeline.
- Assess severity and confidence.
- Recommend containment, remediation, and monitoring actions.

## Key Finding

The main finding was a suspicious multi-port database targeting pattern involving ports `1433`, `1521`, `3306`, and `5432`. The evidence supports possible scanning or probing, but the available Zeek, PCAP, DNS, and endpoint evidence was incomplete, so the investigation did not establish successful unauthorized access or compromise.

## Final Assessment

| Item | Assessment |
|---|---|
| Classification | Suspicious |
| Severity | Medium |
| Confidence | Medium |
| Status | Open / requires further investigation |
| Primary source host | `192.168.194.129` |
| Target | `192.168.194.1` |
| Main activity | Database-port scanning/probing |
| Ports observed | `1433`, `1521`, `3306`, `5432` |

## Recommended Actions

1. Investigate `192.168.194.129` and identify the responsible process, user, and purpose.
2. Review Zeek `conn.log` and DNS records to validate repeated connections and investigate the `.cfd` activity.
3. Restrict unauthorized access to database ports `1433`, `1521`, `3306`, and `5432` where appropriate.
4. Collect endpoint logs and correlate them with Security Onion, Suricata, Zeek, and Wireshark evidence.
5. Continue monitoring for recurrence.

## Repository Contents

```text
security-onion-soc-capstone/
├── README.md
├── docs/
│   └── Idan_Ekitela_Capstone_Project.docx
└── presentation/
    └── Security-Onion-Alert-Analysis-Presentation.pptx
```

## Documentation

The `docs/` directory contains the complete capstone documentation, including the SOC environment summary, alert triage worksheet, Zeek analysis, Suricata analysis, Wireshark five-tuple review, IOC table, timeline, severity assessment, remediation plan, executive summary, technical incident report, and lessons learned.

## Presentation

The `presentation/` directory contains the final SOC alert analysis presentation prepared for the capstone submission.

## Limitations

The investigation is based on the evidence available in the project documentation. Detailed Zeek records, complete PCAP details, exact DNS domain information, and endpoint evidence were not available in the supplied material. Therefore, the findings should be treated as a suspicious activity assessment rather than proof of compromise.

## Ethics and Responsible Use

This project is intended for cybersecurity education, SOC analysis, defensive monitoring, and incident-response practice in an authorized lab or academic environment. The techniques and findings should not be used to access, scan, or interfere with systems without permission.
